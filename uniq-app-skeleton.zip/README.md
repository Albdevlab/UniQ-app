# UNIQ – Universal Network for Information & Qualification
